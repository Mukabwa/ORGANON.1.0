import Playground from "../pages/Playground/Playground";

export default function HomePage() {
    return <Playground />;
}