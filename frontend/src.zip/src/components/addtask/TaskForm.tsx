"use client";

import { useState } from "react";
import Input from "../../primitives/Input/Input";
import TimePicker from "./TimePicker";
import PrioritySelector from "./PrioritySelector";
import RecurrenceSelector, {
    RecurrenceValue,
} from "./RecurrenceSelector";
import styles from "../../styles/components/addtask/TaskForm.module.css";

type Priority = "low" | "medium" | "high";

export default function TaskForm() {
    const [title, setTitle] = useState("");
    const [description, setDescription] = useState("");
    const [date, setDate] = useState("");
    const [time, setTime] = useState("09:00 AM");
    const [priority, setPriority] =
        useState<Priority>("medium");

    const [recurrence, setRecurrence] =
        useState<RecurrenceValue>({
            frequency: "once",
            daysOfWeek: [],
            dayOfMonth: 1,
        });

    return (
        <form className={styles.form}>
            <div className={styles.field}>
                <label htmlFor="task-title">
                    Title
                </label>

                <Input
                    id="task-title"
                    name="title"
                    type="text"
                    variant="standard"
                    placeholder="What needs to be done?"
                    value={title}
                    onChange={(event) =>
                        setTitle(event.target.value)
                    }
                    required
                />
            </div>

            <div className={styles.field}>
                <label htmlFor="task-description">
                    Description
                </label>

                <textarea
                    id="task-description"
                    name="description"
                    placeholder="Add notes..."
                    value={description}
                    onChange={(event) =>
                        setDescription(event.target.value)
                    }
                    rows={4}
                />
            </div>

            <div className={styles.field}>
                <label htmlFor="task-date">
                    Date
                </label>

                <Input
                    id="task-date"
                    name="date"
                    type="date"
                    variant="standard"
                    value={date}
                    onChange={(event) =>
                        setDate(event.target.value)
                    }
                    required
                />
            </div>

            <div className={styles.field}>
                <label>Time</label>

                <TimePicker
                    value={time}
                    onChange={setTime}
                />
            </div>

            <div className={styles.field}>
                <label>Priority</label>

                <PrioritySelector
                    value={priority}
                    onChange={setPriority}
                />
            </div>

            <div className={styles.field}>
                <label>Recurrence</label>

                <RecurrenceSelector
                    value={recurrence}
                    onChange={setRecurrence}
                />
            </div>
        </form>
    );
}