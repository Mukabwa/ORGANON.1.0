"use client";

import Chip from "../../primitives/Chip/Chip";
import styles from "../../styles/components/addtask/RecurrenceSelector.module.css";

export type RecurrenceFrequency =
    | "once"
    | "daily"
    | "weekly"
    | "monthly"
    | "yearly";

export interface RecurrenceValue {
    frequency: RecurrenceFrequency;
    daysOfWeek: string[];
    dayOfMonth: number;
}

interface RecurrenceSelectorProps {
    value?: RecurrenceValue;
    onChange?: (value: RecurrenceValue) => void;
}

const OPTIONS: RecurrenceFrequency[] = [
    "once",
    "daily",
    "weekly",
    "monthly",
    "yearly",
];

const WEEKDAYS = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday",
];

export default function RecurrenceSelector({
    value = {
        frequency: "once",
        daysOfWeek: [],
        dayOfMonth: 1,
    },
    onChange,
}: RecurrenceSelectorProps) {
    const selectFrequency = (
        frequency: RecurrenceFrequency
    ) => {
        onChange?.({
            ...value,
            frequency,
            daysOfWeek:
                frequency === "weekly"
                    ? value.daysOfWeek
                    : [],
        });
    };

    const toggleDay = (day: string) => {
        const days = value.daysOfWeek.includes(day)
            ? value.daysOfWeek.filter(
                (selectedDay) => selectedDay !== day
            )
            : [...value.daysOfWeek, day];

        onChange?.({
            ...value,
            daysOfWeek: days,
        });
    };

    return (
        <div className={styles.selector}>
            <div className={styles.options}>
                {OPTIONS.map((option) => {
                    const selected =
                        value.frequency === option;

                    return (
                        <button
                            key={option}
                            type="button"
                            className={[
                                styles.option,
                                selected ? styles.selected : "",
                            ].join(" ")}
                            onClick={() =>
                                selectFrequency(option)
                            }
                            aria-pressed={selected}
                        >
                            {option.charAt(0).toUpperCase() +
                                option.slice(1)}
                        </button>
                    );
                })}
            </div>

            {value.frequency === "weekly" && (
                <div className={styles.weekdays}>
                    {WEEKDAYS.map((day) => {
                        const selected =
                            value.daysOfWeek.includes(day);

                        return (
                            <button
                                key={day}
                                type="button"
                                className={[
                                    styles.day,
                                    selected ? styles.daySelected : "",
                                ].join(" ")}
                                onClick={() => toggleDay(day)}
                                aria-pressed={selected}
                            >
                                <Chip>
                                    {day.slice(0, 3)}
                                </Chip>
                            </button>
                        );
                    })}
                </div>
            )}

            {value.frequency === "monthly" && (
                <div className={styles.monthly}>
                    <label htmlFor="recurrence-day">
                        Day of month
                    </label>

                    <input
                        id="recurrence-day"
                        type="number"
                        min="1"
                        max="31"
                        value={value.dayOfMonth}
                        onChange={(event) =>
                            onChange?.({
                                ...value,
                                dayOfMonth: Number(
                                    event.target.value
                                ),
                            })
                        }
                    />
                </div>
            )}
        </div>
    );
}