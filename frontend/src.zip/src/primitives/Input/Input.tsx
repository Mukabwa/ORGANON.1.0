import React from "react";
import styles from "./Input.module.css";

type InputVariant =
    | "standard"
    | "filled"
    | "dotted";

interface InputProps
    extends React.InputHTMLAttributes<HTMLInputElement> {
    variant?: InputVariant;
}

export default function Input({
    variant = "standard",
    className = "",
    ...props
}: InputProps) {
    return (
        <input
            className={[
                styles.input,
                styles[`input-${variant}`],
                className,
            ].join(" ")}
            {...props}
        />
    );
}