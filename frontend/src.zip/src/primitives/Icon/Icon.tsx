import React from "react";

import {
    Search,
    Plus,
    ArrowLeft,
    Home,
    Calendar,
    Clock,
    Settings,
    Droplet,
} from "lucide-react";

import styles from "./Icon.module.css";


type IconName =
    | "search"
    | "plus"
    | "back"
    | "home"
    | "calendar"
    | "clock"
    | "settings"
    | "droplet";


type IconVariant =
    | "standard"
    | "gradient"
    | "capsule";


interface IconProps {

    name: IconName;

    variant?: IconVariant;

    size?: number;

    className?: string;

}


const icons = {

    search: Search,

    plus: Plus,

    back: ArrowLeft,

    home: Home,

    calendar: Calendar,

    clock: Clock,

    settings: Settings,

    droplet: Droplet,

};


export default function Icon({

    name,

    variant = "standard",

    size = 20,

    className = "",

}: IconProps) {

    const IconComponent = icons[name];

    const gradientId = `icon-gradient-${name}`;


    return (

        <span

            className={[

                styles.icon,

                styles[`icon-${variant}`],

                className,

            ].join(" ")}

        >

            <IconComponent

                size={size}

                strokeWidth={1.8}

                stroke={

                    variant === "gradient"

                        ? `url(#${gradientId})`

                        : "currentColor"

                }

            >

                {variant === "gradient" && (

                    <defs>

                        <linearGradient

                            id={gradientId}

                            x1="0%"

                            y1="0%"

                            x2="100%"

                            y2="100%"

                        >

                            <stop

                                offset="0%"

                                stopColor="var(--purple)"

                            />

                            <stop

                                offset="100%"

                                stopColor="var(--blush)"

                            />

                        </linearGradient>

                    </defs>

                )}

            </IconComponent>

        </span>

    );

}